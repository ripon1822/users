<nav class="navbar navbar-expand-lg navbar-dark bg-dark ">
  <a class="navbar-brand" href="#">RG's Kitchen</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div  class="container d-flex flex-column flex-md-row justify-content-between" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto ">
      <li class="nav-item ">
        <a class="nav-link" href="<?php echo base_url(); ?>index.php/welcome/index">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url(); ?>index.php/welcome/about">About</a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url(); ?>index.php/welcome/photos">Photos</a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url(); ?>index.php/welcome/contact">Contact us</a>
      </li>
    </ul>
  </div>
</nav>
