<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <?php include("./assets/plugin.php"); ?>
    <style>
        body{
            background-image: url("https://images.unsplash.com/photo-1635151227785-429f420c6b9d?q=80&w=1528&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D");
        }
        .container{
            padding:130px 200px 0px 200px;
        }
        .card-header{
            background-color:#9EB5C2  ;
        }
        .card{
            background-color:#F1F1F1  ;
        }
        .form-control{
            border-radius: 15px;
        }
        .btn{
            width:100%;
            border-radius: 15px;
            color:white;
            background-image: linear-gradient(to right, #89CAFF, #6589FF);
        }
        .btn:hover{
            color:white;
            background-image: linear-gradient(to left, #89CAFF, #6589FF);
        }
        .b1{
            color:red;
        }
        .b1:hover{
            color:red;
        }
        @media only screen and (max-width:768px){
            .container{
                padding:130px 10px 0px 10px;
            }
        }
    </style>
</head>
<body>
    <div class="container ">
        <div class="card m-2 p-2 border">
            <div class="card-header">
                <header >
                    <h2>SINGIN:</h2>
                </header>
            </div>
            <div class="card-body">
                <form action="<?php echo site_url("/user/login") ;?>" method="post">
                    <div class="form-group">
                        Email | Phone: <input type="text" name="uname" required class="form-control " placeholder="email or phone number any one">
                    </div>
                    <div class="form-group">
                        Password: <input type="password" name="pass1" required class="form-control" placeholder="enter your password">
                    </div>
                    <div class="form-group" align="center">
                        <button class="btn btn-sm btn-outline-primary">Login</button>
                        
                        <p class="form-group text-muted">not a member yet? <a href="<?php echo site_url('/user/index'); ?>" class="b1">Singup</a></p>
                    </div>
                </form>
                <?php 
                    if(!empty($this->session->flashdata("message"))){
                        if($this->session->flashdata("message")=='login_success'){
                            echo "<div class='alert alert-success'>Login Successfully...</div>";
                        }else if($this->session->flashdata("message")=='login_error'){
                            echo "<div class='alert alert-warning'>Wrong Cridentials!!</div>";
                        }else if($this->session->flashdata("message")=='logout_success'){
                            echo "<div class='alert alert-info'>Logout Successfully..</div>";
                        }
                    }
                ?>
            </div>
        </div>
    </div>
    
</body>
</html>