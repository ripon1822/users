<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller{
    public function __construct(){
        parent::__construct();
        $this->load->database();
        $this->load->library("session");
    }

    public function index(){
        $this->load->view("users/singup");
    }

    public function all(){
        $isAdmin=false;
        if($this->session->has_userdata("ROLE")){
            $isAdmin=($this->session->ROLE=='admin') ? true:false;
        }else{
            //redirect("user/singin");
        }

        if($isAdmin){
        //$q = $this->db->where("gender","female")->get("users");
        $q = $this->db
                  ->select(["user_id","name","age","gender","phone","email","languages","education","createDate","profile_pic"])
                  ->get("users");
        $usersInfo = $q->result();
        // print "<pre>";
        // print_r($userInfo);
        $this->load->view("users/showall",["users"=>$usersInfo]);
        }else{
            $q = $this->db
            ->select(["user_id","name","age","gender","phone","email","languages","education","createDate","profile_pic"])
            ->where("user_id",$this->session->UDI)
            ->get("users");
            $usersInfo = $q->result();
            $this->load->view("users/showall",["users"=>$usersInfo]);
           // $this->show($this->session->UDI);
        }
    }

    public function show($userid){
        $q = $this->db->where("user_id",$userid)->get("users");
        $userInfo = $q->result();
        // print "<pre>";
        // print_r($userInfo[0]);
        $this->load->view("users/show",["userInfo"=>$userInfo[0]]);
    }

    public function delete($userid){
        $this->db->where("user_id",$userid)->delete("users");
        $rows = $this->db->affected_rows();
        $message = ($rows==1)? "delete_success":"delete_error";
        $this->session->set_flashdata("message",$message);
        redirect("user/all");
    }

    public function submit(){
        //print"<pre>";
        //print_r($_POST);
        //print_r($this->input->POST());


        $name       =$this->input->post("fname").' '.$this->input->post("lname");
        $gender     =$this->input->post("gen");
        $phone      =$this->input->post("phone");
        $email      =$this->input->post("email");
        $age        =$this->input->post("age");
        $languages  =implode(",",$this->input->post("lang"));
        $education  =implode(",",$this->input->post("edu"));
        $city       =$this->input->post("city");
        $state      =$this->input->post("state");
        $pass1      =password_hash($this->input->post("pass1"),PASSWORD_BCRYPT);


        $config['upload_path']          = './uploads/';
        $config['allowed_types']        = 'gif|jpg|png|jpeg';
        $config['max_size']             = 1000;
        $config['file_name']            = time()."-".$config['orig_name'];
        
     print"<pre>";
        $this->load->library('upload', $config);
        if ( ! $this->upload->do_upload('avatar'))
        {
                $error = array('error' => $this->upload->display_errors());
                print_r($error); 
              //  $this->load->view('users/signup', $error);
              $this->session->set_flashdata("file_errors",$error);

        }else{
                $data = array('upload_data' => $this->upload->data());
                $filename = $data['upload_data']['file_name'];
                print_r($data);
               if($data['upload_data']['is_image']==1){
                    $userData=[
                        'name'     =>$name,
                        'gender'   =>$gender,
                        'age'      =>$age,
                        'phone'    =>$phone,
                        'email'    =>$email,
                        'languages'=>$languages,
                        'education'=>$education,
                        'state'    =>$state,
                        'city'     =>$city,
                        'pass'     =>$pass1,
                        'profile_pic'=>$filename
                    ];
                    $this->db->insert('users',$userData);
                    $rows = $this->db->affected_rows();
                    $message = ($rows==1)? "signup_success":"signup_error";
            
                    $this->load->view("users/singup",['message'=>$message]);
                }else{
                    $this->session->set_flashdata('message',"invalid_image_Error");
                }
                redirect('user/index');
        }
    }
    
    public function update($userid){
        //echo $userid;
        //print "<pre>";
        //print_r($this->input->post());

        $config['upload_path']          = './uploads/';
        $config['allowed_types']        = 'gif|jpg|png|jpeg';
        $config['max_size']             = 1000;
        
        $this->load->library('upload', $config);
        
        $this->upload->do_upload('editavatar');
        $data = $this->upload->data();
        $filename='';
        print '<pre>';
        if(!empty($data['file_name'])){
          // die("user has changed");
           $filename = $data['file_name'];
           print_r($filename);

        }else {
            //  die('user not changed any thing');
           $filename = $this->input->post('old_image_path');
           print_r($filename);

        }



        if(empty($this->input->post('pass1')) && empty($this->input->post('pass2'))){
            //echo "user did't change the password";

            $dataToUpdate =[
                'name'          =>$this->input->post('editFname').' '.$this->input->post('editLname'),
                'age'           =>$this->input->post('editAge'),
                'gender'        =>$this->input->post('editGender'),
                'phone'         =>$this->input->post('editPhone'),
                'email'         =>$this->input->post("editEmail"),
                'state'         =>$this->input->post('editState'),
                'city'          =>$this->input->post('editCity'),
                'languages'     =>implode(",",$this->input->post('editLang')),
                'education'     =>implode(",",$this->input->post('editEdu')),
                'profile_pic'   =>$filename
            ];
        }else{
            //echo "user wants to reset password";

            $dataToUpdate =[
                'name'          =>$this->input->post('editFname').' '.$this->input->post('editLname'),
                'age'           =>$this->input->post('editAge'),
                'gender'        =>$this->input->post('editGender'),
                'phone'         =>$this->input->post('editPhone'),
                'email'         =>$this->input->post("editEmail"),
                'state'         =>$this->input->post('editState'),
                'city'          =>$this->input->post('editCity'),
                'languages'     =>implode(",",$this->input->post('editLang')),
                'education'     =>implode(",",$this->input->post('editEdu')),
                'pass'          =>password_hash($this->input->post('pass1'),PASSWORD_BCRYPT),
                'profile_pic'   =>$filename
            ];
        }

        $this->db->where("user_id",$userid)->update("users",$dataToUpdate);
        $rows = $this->db->affected_rows();
        $message = ($rows==1) ? "update_success":"update_error";
        $this->session->set_flashdata("message",$message);
       // redirect("user/all");
    }

    public function singin(){
        $this->load->view("users/login");
    }

    public function login(){
        // print "<pre>";
        // print_r($this->input->post());
        $userName = $this->input->post('uname');
        $pass1    = $this->input->post('pass1');
        $q = $this->db->select(["user_id","name","pass","role"])
                      ->where("email",$userName)
                      ->or_where("phone",$userName)
                      ->get("users");
        $data = $q->result();
        $old_db_hashed_pass = $data[0]->pass;
        //echo $old_db_hashed_pass;
        //print_r($data[0]);

        $isMatch = (password_verify($pass1,$old_db_hashed_pass)) ? true:false;
            if($isMatch){
                $this->session->set_userdata("USER",$data[0]->name);
                $this->session->set_userdata("UDI",$data[0]->user_id);
                $this->session->set_userdata("ROLE",$data[0]->role);
                $this->session->set_flashdata("message","login_success");
                redirect("user/all");
            }else{
                $this->session->set_flashdata("message","login_error");
            }
            redirect("user/singin");
    }

    public function logout(){
        $this->session->unset_userdata("USER");
        $this->session->unset_userdata("UDI");
        $this->session->unset_userdata("ROLE");
        $this->session->set_flashdata("message","logout_success");
        redirect("user/singin");
    }
}

?>