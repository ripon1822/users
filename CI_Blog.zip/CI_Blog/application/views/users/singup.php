<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Singup</title>
    <?php include("./assets/plugin.php"); ?>
</head>
<body>
    <div class="container">
    <?php
       if(!empty($message)){
            if($message=='signup_success'){
                echo "<div class='alert alert-success'>SignUp Successflly Completed.</div>";  
            }else if($message=='signup_error'){
                echo "<div class='alert alert-danger'>Unable to SignUp Now.</div>";
            }
       }
    ?>
        <div class="card">
            <div class="card-header">
                <header class="modal-header">
                    <h4>Singup:</h4>
                </header>
            </div>
            <div class="card-body">
                <form enctype="multipart/form-data" action="<?php echo site_url('/user/submit') ?>" method="post">
                    <div class="form-group">
                        <div class="row">
                            <div class="col">
                                First Name: <input type="text" name="fname" style="text-transform:capitalize;" required class="form-control" placeholder="e.g.first name">
                            </div>
                            <div class="col">
                                Last Name: <input type="text" name="lname" style="text-transform:capitalize;" required class="form-control" placeholder="e.g.last name">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        Age: <input type="text" name="age" required min="18" max="80" class="form-control" placeholder="18 to 80 years">
                    </div>
                    <div class="form-group">
                        Gender:
                        <input type="radio" name="gen" id="gen1" required value="Male">Male
                        <input type="radio" name="gen" id="gen2" required value="Female">Female
                        <input type="radio" name="gen" id="gen3" required value="Transgender">Transgender
                    </div>
                    <div class="form-group">
                        Phone: <input type="text" name="phone" maxlength="10" class="form-control" required pattern="[0-9]{10}" placeholder="10 digit mobile number">
                    </div>
                    <div class="form-group">
                        Email: <input type="email" name="email" required class="form-control" placeholder="example@gmail.com">
                    </div>
                    <div class="form-group">
                        Upload Your Profile Image:
                        <input type="file" name="avatar" onchange="loadImg(event)" required class="form-control">
                        <div id="img_preview" class="img-thumbnail"></div>
                        <script>
                            function loadImg(event){
                                let img = event.target.files[0];
                                console.log(img);
                                let image_url = URL.createObjectURL(img);
                                console.log(image_url);
                                document.getElementById("img_preview").innerHTML=`
                                <img src='${image_url}' height='120px' width='120px'/>
                              `;
                            }
                        </script>
                    </div>
                    <div class="form-group">
                        <div class="row">
                            <div class="col">
                                State:
                                <select name="state" id="state" class="form-control" required>
                                    <option value="">Choose your State....</option>
                                    <option>WEST BENGAL</option>
                                    <option>MAHARASHTRA</option>
                                    <option>BIHAR</option>
                                    <option>TAMIL NADU</option>
                                    <option>JHARKHAND</option>
                                    <option>KARNATAKA</option>
                                    <option>SIKKIM</option>
                                </select>
                            </div>
                            <div class="col">
                                City:
                                <select name="city" id="city" class="form-control" required>
                                    <option value="">Choose your City....</option>
                                    <option>KOLKATA</option>
                                    <option>MUMBAI</option>
                                    <option>PATNA</option>
                                    <option>CHENNAI</option>
                                    <option>RANCHI</option>
                                    <option>BANGALORE</option>
                                    <option>GANGTOK</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        Languages Know:
                        <select name="lang[]" multiple class="form-control" style="height:150px;">
                            <option>Bengali</option>
                            <option>Hindi</option>
                            <option>English</option>
                            <option>Tamil</option>
                            <option>Telegu</option>
                            <option>Nepali</option>
                        </select>
                    </div>
                    <div class="form-group">
                        Education:
                        <input type="checkbox" name="edu[]" value="10th">10<sup>th</sup>
                        <input type="checkbox" name="edu[]" value="12th">12<sup>th</sup>
                        <input type="checkbox" name="edu[]" value="Gradutaion">Gradutaion
                        <input type="checkbox" name="edu[]" value="Post-Gradutaion">Post-Gradutaion
                    </div>
                    <div class="form-group">
                        <div class="row">
                            <div class="col">
                                Password: <input type="password" name="pass1" id="pass1" required class="form-control" placeholder="enter your password">
                            </div>
                            <div class="col">
                                Confirm Password: <input type="password" name="pass2" id="pass2" required class="form-control" placeholder="enter your Confirm password">
                            </div>
                        </div>
                    </div>
                    <div class="form-group" align="center">
                        <button class="btn btn-sm btn-outline-primary">SUBMIT</button>
                        <button type="reset" class="btn btn-sm btn-outline-danger">RESET</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
</body>
</html>