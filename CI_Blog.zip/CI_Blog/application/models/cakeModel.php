<?php 
class cakeModel extends CI_Model{
    public $cakeList = [
        0=>['cake_id'=>1501,'cake_name'=>'Marble Mania Cake','qty'=>70,'price'=>185,'pic'=>"assets/cake/Marble Mania Cake.jfif"],
        1=>['cake_id'=>1502,'cake_name'=>'Butterscotch Cake','qty'=>65,'price'=>280,'pic'=>"assets/cake/Butterscotch.jfif"],
        2=>['cake_id'=>1503,'cake_name'=>'Mango Samoa Cake','qty'=>83,'price'=>340,'pic'=>"assets/cake/Mango Samoa Cake.jfif"],
        3=>['cake_id'=>1504,'cake_name'=>'White Forest Cake','qty'=>58,'price'=>530,'pic'=>"assets/cake/White Forest Cake.jfif"]
    ];
}
?>