<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>welcome</title>
    <?php include("./assets/plugin.php"); ?>
    <style>
        .b1{
            color:red;
        }
        .b1:hover{
            color:red;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <?php 
           if($this->session->has_userdata("USER")){
        ?>
        <div class="" align="right">
            Welcome <?php echo $this->session->USER; ?>
            <a href="<?php echo site_url('user/logout') ;?>" class="b1">Logout</a>
        </div>
        <?php }else{
                       echo "<script>alert('Please login to access this Page');
                       window.location.href='".site_url('user/singin')."';
                       </script>";
                   }
        ?>
        <?php
            if(!empty($this->session->flashdata("message"))){
                if($this->session->flashdata("message")=='delete_success'){
                    echo "<div class='alert alert-info'>One User profile has been remove successfully...</div>";
                }else if($this->session->flashdata("message")=='delete_error'){
                    echo "<div class='alert alert-warning'>Unable to delete User Profile ! Please try after sometime...</div>";
                }else if($this->session->flashdata("message")=='update_success'){
                    echo "<div class='alert alert-success'>User profile Update Successfully..</div>";
                }else if($this->session->flashdata("message")=='update_error'){
                    echo "<div class='alert alert-warning'>Unable to Update right now !! Please try after sometimes...</div>";
                }
            }
        ?>
        <div class="table-responsive">
            <?php if(!empty($users)){ ?>
            <table class="table table-hover table-bordered">
                <tr bgcolor="#9EB5C2">
                    <th>#</th>
                    <th>Profile Pic:</th>
                    <th>Name:</th>
                    <th>Age:</th>
                    <th>Gender:</th>
                    <th>Phone:</th>
                    <th>Email:</th>
                    <th>languages Known:</th>
                    <th>Education Qualification:</th>
                    <th>Account Created:</th>
                </tr>
                <?php foreach($users as $uObj){ ?>
                <tr >
                    <td><a href="<?php echo site_url('/user/show');?>/<?php echo $uObj->user_id; ?>" class="btn btn-sm btn-outline-info">View</a></td>
                    <td><img src="http://localhost/ripon/CI_Blog/uploads/<?php echo $uObj->profile_pic;?>" height="80px" width="80px" alt="no image" title="<?php echo $uObj->name;?>'s Pic"/></td>
                    <td><?php echo $uObj->name; ?></td>
                    <td><?php echo $uObj->age; ?></td>
                    <td><?php echo $uObj->gender; ?></td>
                    <td><?php echo $uObj->phone; ?></td>
                    <td><?php echo $uObj->email; ?></td>
                    <td><?php echo $uObj->languages; ?></td>
                    <td><?php echo $uObj->education; ?></td>
                    <td><?php echo $uObj->createDate; ?></td>
                </tr>
                <?php } ?>
            </table>
            <?php } ?>
        </div>
        
    </div>
    
</body>
</html>