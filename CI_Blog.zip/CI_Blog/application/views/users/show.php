<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>welcome</title>
    <?php include("./assets/plugin.php"); ?>
    <style>
        .hidden{
            display:none;
        }
        .show{
            display:block;
        }
        .b1{
            color:red;
        }
        .b1:hover{
            color:red;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <?php 
            if($this->session->has_userdata("USER")){
        ?>
        <div align="right">
            Welcome <?php echo $this->session->USER;?>
            <a href="<?php echo site_url('user/logout'); ?>" class="b1">Logout</a>
        </div>
        <?php
            }else{
                echo "<script>alert('Please login to access this Page');
                    window.location.href='".site_url('user/singin')."';
                    </script>";
                }
            ?>
        <div class="card border">          
            <div class="card-header">
                <header class="modal-header">
                    <h4>#<?php echo $userInfo->name;?></h4>
                </header>
            </div>
            <div class="card-body">
                <?php if(!empty($userInfo)){ ?>  
                    <div class="form-group">
                        <form action="<?php echo site_url("/user/update");?>/<?php echo $userInfo->user_id ;?>" enctype="multipart/form-data" method="post">
                        <div class="form-group">
                            <img src="http://localhost/ripon/CI_Blog/uploads/<?php echo $userInfo->profile_pic; ?>" alt="no image" title="<?php echo $userInfo->name;?>'s Pic" class="rounded mx-auto d-block" height="180px" width="180px">
                            <input type="file" name="editavatar" class="form-control">
                            <input type="hidden" name="old_image_path" value="<?php echo $userInfo->profile_pic; ?>">
                       </div> 
                        <div class="form-group">                           
                        <?php $nameArr = explode(" ",$userInfo->name); ?>
                            <div class="row">
                                <div class="col">
                                    First Name: <input type="text" name="editFname" style="text-transform:capitalize;" class="form-control" value="<?php echo $nameArr[0]; ?>">
                                </div>
                                <div class="col">
                                    Last Name: <input type="text" name="editLname" style="text-transform:capitalize;" class="form-control" value="<?php echo $nameArr[1]; ?>">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            Age : <input type="number" name="editAge" class="form-control" value="<?php echo $userInfo->age;?>">
                        </div>
                        <div class="form-group">
                            <?php $gender = $userInfo->gender ?>
                            Gender : 
                            <input type="radio" name="editGender" id="gen1"  value="Male"<?php if($gender=='Male') {?>checked<?php }?>>Male
                            <input type="radio" name="editGender" id="gen2"  value="Female"<?php if($gender=='Female') {?>checked<?php }?>>Female
                            <input type="radio" name="editGender" id="gen3"  value="Transgender"<?php if($gender=='Transgender') {?>checked<?php }?>>Transgender
                        </div>
                        <div class="form-group">
                            Phone : <input type="number" name="editPhone" class="form-control" value="<?php echo $userInfo->phone;?>">
                        </div>
                        <div class="form-group">
                            Email : <input type="text" name="editEmail" class="form-control" value="<?php echo $userInfo->email;?>">
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col">
                                    <?php $state = explode(",",$userInfo->state) ?>
                                    State:
                                        <select name="editState" class="form-control">
                                            <option <?php if(in_array("WEST BENGAL",$state)){?> selected <?php } ?>>WEST BENGAL</option>
                                            <option <?php if(in_array("MAHARASHTRA",$state)){?> selected <?php } ?>>MAHARASHTRA</option>
                                            <option <?php if(in_array("BIHAR",$state)){?> selected <?php } ?>>BIHAR</option>
                                            <option <?php if(in_array("TAMIL NADU",$state)){?> selected <?php } ?>>TAMIL NADU</option>
                                            <option <?php if(in_array("JHARKHAND",$state)){?> selected <?php } ?>>JHARKHAND</option>
                                            <option <?php if(in_array("KARNATAKA",$state)){?> selected <?php } ?>>KARNATAKA</option>
                                            <option <?php if(in_array("SIKKIM",$state)){?> selected <?php } ?>>SIKKIM</option>
                                        </select>                      
                                </div>
                                <div class="col">
                                    <?php $city = explode(",",$userInfo->city) ?>
                                    State:
                                        <select name="editCity" class="form-control">
                                            <option <?php if(in_array("KOLKATA",$city)){?> selected <?php } ?>>KOLKATA</option>
                                            <option <?php if(in_array("MUMBAI",$city)){?> selected <?php } ?>>MAHARASHTRA</option>
                                            <option <?php if(in_array("PATNA",$city)){?> selected <?php } ?>>PATNA</option>
                                            <option <?php if(in_array("CHENNAI",$city)){?> selected <?php } ?>>CHENNAI</option>
                                            <option <?php if(in_array("RANCHI",$city)){?> selected <?php } ?>>RANCHI</option>
                                            <option <?php if(in_array("BANGALORE",$city)){?> selected <?php } ?>>BANGALORE</option>
                                            <option <?php if(in_array("GANGTOK",$city)){?> selected <?php } ?>>GANGTOK</option>
                                        </select>                      
                                </div>
                            </div>
                        </div>
                       <div class="form-group">
                        <?php $languages = explode(",",$userInfo->languages) ?>
                            Languages Known:
                            <select name="editLang[]" multiple class="form-control" style="height:150px;">
                                <option <?php if(in_array("Bengali",$languages)){?> selected <?php } ?>>Bengali</option>
                                <option <?php if(in_array("Hindi",$languages)){?> selected <?php } ?>>Hindi</option>
                                <option <?php if(in_array("English",$languages)){?> selected <?php } ?>>English</option>
                                <option <?php if(in_array("Tamil",$languages)){?> selected <?php } ?>>Tamil</option>
                                <option <?php if(in_array("Telegu",$languages)){?> selected <?php } ?>>Telegu</option>
                                <option <?php if(in_array("Nepali",$languages)){?> selected <?php } ?>>Nepali</option>
                            </select>
                        </div>
                       <div class="form-group">
                        <?php $education = explode(",",$userInfo->education); 
                        //print_r($education);?>
                            Education Qualification : 
                                <input type="checkbox" name="editEdu[]" value="10th" <?php if(in_array('10th',$education)){?>checked<?php }?>>10<sup>th</sup>
                                <input type="checkbox" name="editEdu[]" value="12th" <?php if(in_array('12th',$education)){?>checked<?php }?>>12<sup>th</sup>
                                <input type="checkbox" name="editEdu[]" value="Gradutaion" <?php if(in_array('Gradutaion',$education)){?>checked<?php }?>>Gradutaion
                                <input type="checkbox" name="editEdu[]" value="Post-Gradutaion" <?php if(in_array('Post-Gradutaion',$education)){?>checked<?php }?>>Post-Gradutaion
                       </div>
                       <div class="form-group">
                        <input type="checkbox" id="sh" onchange="togglePass()">
                        <strong class="text-info">Do you want to set new Password ?</strong>
                       </div>
                       <fieldset class="card m-2 p-2 border" id="passArea" >
                            <legend>
                                <h4>Security</h4>
                            </legend>
                            <div class="row">
                                <div class="col">
                                    Password: <input type="password" name="pass1" id="pass1" class="form-control">
                                </div>
                                <div class="col">
                                    Confirm Password: <input type="password" name="pass2" id="pass2" class="form-control">
                                </div>
                            </div>
                       </fieldset>
                       <script>
                            document.getElementById("passArea").classList.add("hidden");
                                function togglePass(){
                                    let passShow= document.getElementById("sh");
                                    if(passShow.checked){
                                        document.getElementById("passArea").classList.remove("hidden");
                                        document.getElementById("passArea").classList.add("show");
                                    }else{
                                        document.getElementById("passArea").classList.remove("show");
                                        document.getElementById("passArea").classList.add("hidden");
                                    }
                                }
                       </script>
                        <p>Account Created : <?php echo date("d-m-y",strtotime($userInfo->createDate));?></p>
                        <p><a href="<?php echo site_url('/user/all'); ?>" class="btn btn-sm btn-outline-info">Back</a></p>
                        <div class="form-group" align="center">
                            <button class="btn btn-sm btn-outline-primary">Update</button> |
                            <a href="<?php echo site_url('/user/delete')?>/<?php echo $userInfo->user_id; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('do you want do delete this record?')">Delete</a>      
                        </div>
                        </form>    
                    </div>
                <?php }?>
            </div>
        </div>
    </div>
    
</body>
</html>