<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
    <?php include("./assets/plugin.php"); ?>
</head>
<body>
    <div class="container">
        <div class="card m-2 p-2">
            <div class="card-header">
                <header class="modal-header">
                    <h4>Displaying all Cakes</h4>
                </header>
            </div>
            <div class="card-body">
                <?php 
                    if(!empty($cake)){
                        $grandPrice=0;
                ?>
                <table class="table table-hover table-bordered">
                    <tr>
                        <th>Cake ID:</th>
                        <th>Cake Name:</th>
                        <th>Qty:</th>
                        <th>Price:</th>
                        <th>Total Price:</th>
                        <th>Cake Image:</th>
                    </tr>
                    <tbody>
                    <?php foreach($cake as $cObj){ 
                         $totalPrice=$cObj['qty']*$cObj['price'];    
                    ?>
                    <tr>
                        <td><?php echo $cObj['cake_id']; ?></td>
                        <td><?php echo $cObj['cake_name']; ?></td>
                        <td><?php echo $cObj['qty']; ?></td>
                        <td><?php echo $cObj['price']; ?></td>
                        <td><?php echo $totalPrice; ?></td>
                        <td><img src="<?php echo $cObj['pic']; ?>" height="100px" width="100px" class="img-thumbnail" title="<?php echo $cObj['cake_name'] ?>"/></td>
                    </tr>
                    <?php 
                           $grandPrice+=$totalPrice;
                     } ?>
                    </tbody>
                    <tfoot>
                        <td colspan="6" align="center">
                            <span class="badge badge-pill badge-success float-right">Grand Total Price : &#8377;<?php echo $grandPrice ?></span>
                            <span class="badge badge-pill badge-danger float-right">Averge Price : &#8377;<?php echo $grandPrice/count($cake); ?></span>&nbsp;&nbsp;
                        </td>
                    </tfoot>
                    
                </table>
                <?php } ?>
            </div>
        </div>
    </div>
    
</body>
</html>