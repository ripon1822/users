<?php include("./assets/plugin.php"); ?>
<?php include("./assets/header.php"); ?>
<div class="container">
<fieldset class="card m-2 p-2">
    <legend>
        <h4>CONTACT US:</h4>
    </legend>
    <div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d57710807.64444755!2d-0.7283992499999927!3d28.012609699999995!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae15006e4c3947%3A0x8debeeb61c3a49b8!2zUkfigJlzIEtpdGNoZW4!5e0!3m2!1sen!2sin!4v1718852273358!5m2!1sen!2sin" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>

    </div>
</fieldset>
    </div>
<?php include("./assets/footer.php"); ?>