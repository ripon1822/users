<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class cake extends CI_Controller{

    public function index(){

        $this->load->model("cakeModel","cm");
        
        $this->load->view("cake/index",['cake'=>$this->cm->cakeList]);
    }
}
?>