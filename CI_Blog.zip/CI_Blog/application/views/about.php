<?php include("./assets/plugin.php"); ?>
<?php include("./assets/header.php"); ?>
<div class="container">
<fieldset class="card m-2 p-2">
    <legend>
        <h4 align="center"> ABOUT US:</h4>
    </legend>
    <div>
        <p style="text-align:justify">
        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quidem aperiam perspiciatis dolores alias, officia eos minus! Maiores impedit voluptate aperiam, soluta nobis excepturi voluptatum cumque eveniet voluptates at perferendis itaque.
        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quidem aperiam perspiciatis dolores alias, officia eos minus! Maiores impedit voluptate aperiam, soluta nobis excepturi voluptatum cumque eveniet voluptates at perferendis itaque.
        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quidem aperiam perspiciatis dolores alias, officia eos minus! Maiores impedit voluptate aperiam, soluta nobis excepturi voluptatum cumque eveniet voluptates at perferendis itaque.
        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quidem aperiam perspiciatis dolores alias, officia eos minus! Maiores impedit voluptate aperiam, soluta nobis excepturi voluptatum cumque eveniet voluptates at perferendis itaque.
        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quidem aperiam perspiciatis dolores alias, officia eos minus! Maiores impedit voluptate aperiam, soluta nobis excepturi voluptatum cumque eveniet voluptates at perferendis itaque.
        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quidem aperiam perspiciatis dolores alias, officia eos minus! Maiores impedit voluptate aperiam, soluta nobis excepturi voluptatum cumque eveniet voluptates at perferendis itaque.
        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quidem aperiam perspiciatis dolores alias, officia eos minus! Maiores impedit voluptate aperiam, soluta nobis excepturi voluptatum cumque eveniet voluptates at perferendis itaque.
        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quidem aperiam perspiciatis dolores alias, officia eos minus! Maiores impedit voluptate aperiam, soluta nobis excepturi voluptatum cumque eveniet voluptates at perferendis itaque.
        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quidem aperiam perspiciatis dolores alias, officia eos minus! Maiores impedit voluptate aperiam, soluta nobis excepturi voluptatum cumque eveniet voluptates at perferendis itaque.
        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quidem aperiam perspiciatis dolores alias, officia eos minus! Maiores impedit voluptate aperiam, soluta nobis excepturi voluptatum cumque eveniet voluptates at perferendis itaque.
        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quidem aperiam perspiciatis dolores alias, officia eos minus! Maiores impedit voluptate aperiam, soluta nobis excepturi voluptatum cumque eveniet voluptates at perferendis itaque.
        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quidem aperiam perspiciatis dolores alias, officia eos minus! Maiores impedit voluptate aperiam, soluta nobis excepturi voluptatum cumque eveniet voluptates at perferendis itaque.
        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quidem aperiam perspiciatis dolores alias, officia eos minus! Maiores impedit voluptate aperiam, soluta nobis excepturi voluptatum cumque eveniet voluptates at perferendis itaque.
        </p>
    </div>   
</fieldset>
</div>
<?php include("./assets/footer.php"); ?>