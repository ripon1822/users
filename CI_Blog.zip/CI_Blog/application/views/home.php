<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Welcome</title>
	<?php include("./assets/plugin.php"); ?>
</head>
<body>
	<?php include("./assets/header.php"); ?>
	
<div class="jumbotron">
	<h1 align="center">Welcome to RG's Kitchen</h1>
</div>
	<div class="container-fluid">
		<header class="modal-header">
			<h4>Welcome to codeIngitel</h4>
		</header>
		<article style="text-align:justify;">
			<p class="card m-2 p-2">Lorem ipsum dolor sit amet consectetur adipisicing elit. Assumenda fugit qui quos optio eum minima earum quis expedita cumque, eveniet et, aperiam recusandae! Maiores, non animi. Culpa doloremque itaque ipsum.</p>
			<p class="card m-2 p-2">Lorem ipsum dolor sit amet consectetur adipisicing elit. Assumenda fugit qui quos optio eum minima earum quis expedita cumque, eveniet et, aperiam recusandae! Maiores, non animi. Culpa doloremque itaque ipsum.</p>
			<p class="card m-2 p-2">Lorem ipsum dolor sit amet consectetur adipisicing elit. Assumenda fugit qui quos optio eum minima earum quis expedita cumque, eveniet et, aperiam recusandae! Maiores, non animi. Culpa doloremque itaque ipsum.</p>
			<p class="card m-2 p-2">Lorem ipsum dolor sit amet consectetur adipisicing elit. Assumenda fugit qui quos optio eum minima earum quis expedita cumque, eveniet et, aperiam recusandae! Maiores, non animi. Culpa doloremque itaque ipsum.</p>
			<p class="card m-2 p-2">Lorem ipsum dolor sit amet consectetur adipisicing elit. Assumenda fugit qui quos optio eum minima earum quis expedita cumque, eveniet et, aperiam recusandae! Maiores, non animi. Culpa doloremque itaque ipsum.</p>
			<p class="card m-2 p-2">Lorem ipsum dolor sit amet consectetur adipisicing elit. Assumenda fugit qui quos optio eum minima earum quis expedita cumque, eveniet et, aperiam recusandae! Maiores, non animi. Culpa doloremque itaque ipsum.</p>
			<p class="card m-2 p-2">Lorem ipsum dolor sit amet consectetur adipisicing elit. Assumenda fugit qui quos optio eum minima earum quis expedita cumque, eveniet et, aperiam recusandae! Maiores, non animi. Culpa doloremque itaque ipsum.</p>
			
		</article>
	</div>
	<?php include("./assets/footer.php"); ?>
</body>
</html>